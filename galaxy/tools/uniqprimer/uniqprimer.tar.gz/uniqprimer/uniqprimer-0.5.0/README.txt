Installing the modded python scripts
1- copy <uniqprimer.py> to the uniqprimer installation directory
2- copy utils.py to primertools/ directory in the install dir
3- re-run uniqprimer setup (sudo python setup.py)

